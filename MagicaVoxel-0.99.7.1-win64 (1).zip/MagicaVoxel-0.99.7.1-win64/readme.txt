[MagicaVoxel : 8-bit Voxel Editor & Renderer created by ephtracy]
================================
date    : 5/29/2023

version : 0.99.7.1

os      : win64

website : https://ephtracy.github.io/

twitter : @ ephtracy

[Credits]
================================
Intel® Open Image Denoise : https://openimagedenoise.github.io
HDRi : HDRI-Hub Free Samples : https://www.hdri-hub.com/hdrishop/freesamples
Icon : Font Awesome Free Version : https://fontawesome.com
Icon : Google Material Design : https://material.io/tools/icons/?style=baseline
Icon : Ionicons : https://ionicons.com
Model Sample : Mini Mike's Metro Minis : https://github.com/mikelovesrobots/mmmm